# image_processing

Description:
    The package image_processing is used to:
        Processing:
            - Histogram matching
            - Structural similarity
            - Resize image
        Utils:
            - Read image
            - Save image
            - Plot image
            - Plot result
            - Plot histogram

## Instalation
 Use the package manager [pip] to install package_name

 pip install package_name

## Usage
 python
  from package_name.module1_name import file1_name
  file1_name.my_function()

## Author
Mauricio Oliveira
